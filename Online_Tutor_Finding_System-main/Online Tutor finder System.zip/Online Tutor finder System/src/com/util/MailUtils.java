package com.util;

import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.model.Student;

public class MailUtils {

	public String getRandom() {
		Random random = new Random();
		int randomCode = random.nextInt(999999);
		return String.format("%06d", randomCode);
	}

	public boolean sendMail(Student student) {
		boolean flag = false;

		String recipient = student.getEmail();
		String sender = "sender@gmail.com";
		String subject = "Reseting Code";
		String content = "<h1>Hii Rudhir..!</h1><br>your reset code is" + student.getCode();
		try {
			Properties properties = System.getProperties();

			properties.put("mail.smtp.host", "smtp.gmail.com");
			properties.put("mail.smtp.auth", "true");
			properties.put("mail.smtp.port", "587");
			properties.put("mail.smtp.starttls.enable", "true");
			properties.put("mail.smtp.starttls.required", "true");

			Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("rudhir1801@gmail.com", "bejbrtablboteuzj");
				}
			});

			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(sender));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
			message.setSubject(subject);
			message.setContent(content, "text/html");

			Transport.send(message);

			flag = true;
			System.out.println("Mail successfully sent");
		} catch (Exception e) {

		}
		return flag;

	}

}
