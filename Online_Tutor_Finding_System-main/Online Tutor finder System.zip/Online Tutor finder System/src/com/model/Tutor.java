package com.model;

import java.sql.Date;

public class Tutor {
	private int tutor_id;
	private String name;
	private String email;
	private Date DOB;
	private String mobile_no;
	private String gender;
	private String address;
	private String qualification;
	private String course;
	private String password;

	public Tutor() {

	}

	public int getTutor_id() {
		return tutor_id;
	}

	public void setTutor_id(int tutor_id) {
		this.tutor_id = tutor_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dOB) {
		DOB = dOB;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Tutor [tutor_id=" + tutor_id + ", name=" + name + ", email=" + email + ", DOB=" + DOB + ", mobile_no="
				+ mobile_no + ", gender=" + gender + ", address=" + address + ", qualification=" + qualification
				+ ", course=" + course + ", password=" + password + "]";
	}

}