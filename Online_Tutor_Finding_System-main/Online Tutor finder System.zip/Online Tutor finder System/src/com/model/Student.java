package com.model;

import java.sql.Date;

public class Student {
	private int student_id;
	private String name;
	private String email;
	private Date DOB;
	private String mobile_no;
	private String gender;
	private String address;
	private String shcool_name;
	private String student_Class;
	private String password;
	private String subject;

	private String code;

	public Student() {

	}
	
	

	public Student(String email, String code) {
		super();
		this.email = email;
		this.code = code;
	}



	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dOB) {
		DOB = dOB;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getShcool_name() {
		return shcool_name;
	}

	public void setShcool_name(String shcool_name) {
		this.shcool_name = shcool_name;
	}

	public String getStudent_Class() {
		return student_Class;
	}

	public void setStudent_Class(String student_Class) {
		this.student_Class = student_Class;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String toString() {
		return "Student [student_id=" + student_id + ", name=" + name + ", email=" + email + ", DOB=" + DOB
				+ ", mobile_no=" + mobile_no + ", gender=" + gender + ", address=" + address + ", shcool_name="
				+ shcool_name + ", student_Class=" + student_Class + ", password=" + password + ", subject=" + subject
				+ ", code=" + code + "]";
	}
	
}