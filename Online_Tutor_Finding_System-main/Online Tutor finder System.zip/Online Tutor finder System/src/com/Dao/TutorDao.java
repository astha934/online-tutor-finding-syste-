package com.Dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Dao.GenericDao;
import com.model.Tutor;

public class TutorDao extends GenericDao {

	public TutorDao() {
		getConnection();
	}

	public String insertTutor(Tutor tutor) {
		String sql = "insert into tutor_register(tutor_id, tutor_name, email, DOB, gender, mobile_no, address, password, status) values(?, ?, ?, ?, ?, ?, ?, ?,'no')";
		String result = "";
		PreparedStatement ps = null;
		try {
			System.out.println(con);
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setInt(++parameterIndex, tutor.getTutor_id());
			ps.setString(++parameterIndex, tutor.getName());
			ps.setString(++parameterIndex, tutor.getEmail());
			ps.setDate(++parameterIndex, tutor.getDOB());
			ps.setString(++parameterIndex, tutor.getGender());
			ps.setString(++parameterIndex, tutor.getMobile_no());
			ps.setString(++parameterIndex, tutor.getAddress());
			ps.setString(++parameterIndex, tutor.getPassword());

			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been inserted";
			} else {
				result = "Failed to insert the data";
			}
		} catch (SQLException e) {
			result = "Failed to insert due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(result);
		System.out.println("---------------------------------------------------");
		return result;
	}

	public String updateTutor(Tutor tutor) {
		String sql = "update tutor_register set tutor_name =?, email =?, DOB =?, gender =?, mobile_no =?, address =?, qualification =?, courses =? Where tutor_id=?";
		String result = "";
		PreparedStatement ps = null;
		try {
			System.out.println(sql);
			System.out.println(tutor);
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;

			ps.setString(++parameterIndex, tutor.getName());
			ps.setString(++parameterIndex, tutor.getEmail());
			ps.setDate(++parameterIndex, tutor.getDOB());
			ps.setString(++parameterIndex, tutor.getGender());
			ps.setString(++parameterIndex, tutor.getMobile_no());
			ps.setString(++parameterIndex, tutor.getAddress());
			ps.setString(++parameterIndex, tutor.getQualification());
			ps.setString(++parameterIndex, tutor.getCourse());
			ps.setInt(++parameterIndex, tutor.getTutor_id());

			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been updated";
			} else {
				result = "Failed to updated the data";
			}
		} catch (SQLException e) {
			result = "Failed to updated due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(result);
		System.out.println("---------------------------------------------------");
		return result;
	}

	public String deleteTutor(Tutor tutor) {
		String sql = "DELETE FROM tutor_register WHERE tutor_id = ?";
		String result = "";
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setInt(++parameterIndex, tutor.getTutor_id());
			// ps.setString(++parameterIndex, tutor.getEmail());
			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been deleted";
			} else {
				result = "failed to delete the data";
			}
		} catch (SQLException e) {
			result = "Failed to delete due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	public List<Tutor> fetchAllTutor() {
		String sql = "select tutor_id, tutor_name, email, DOB, gender, mobile_no, address, password, qualification, courses from tutor_register where status='yes'";
		List<Tutor> tutors = new ArrayList<Tutor>();
		PreparedStatement ps = null;
		try {
			System.out.println(sql);
			ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					Tutor tutor = new Tutor();
					int tutor_id = rs.getInt("tutor_id");
					String name = rs.getString("tutor_name");
					String email = rs.getString("email");
					Date date = rs.getDate("DOB");
					String gender = rs.getString("gender");
					String mobile_no = rs.getString("mobile_no");
					String address = rs.getString("address");
					String password = rs.getString("password");
					String qualification = rs.getString("qualification");
					String courses = rs.getString("courses");

					tutor.setTutor_id(tutor_id);
					tutor.setName(name);
					tutor.setEmail(email);
					tutor.setDOB(date);
					tutor.setGender(gender);
					tutor.setMobile_no(mobile_no);
					tutor.setAddress(address);
					tutor.setPassword(password);
					tutor.setQualification(qualification);
					tutor.setCourse(courses);

					tutors.add(tutor);
				}
				System.out.println("All fetched");
			} else {
				System.out.println("No Record Found");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return tutors;
	}

	public String insertTutorList(List<Tutor> tutorList) {
		String result = "";
		for (Tutor tutor : tutorList) {
			result = insertTutor(tutor);
		}
		return result;
	}

	public boolean validateUser(Tutor tutor) {
		String sql = "select * from tutor_register where email = ? and password = ? and status='yes'";
		try {
			System.out.println(con);
			PreparedStatement ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setString(++parameterIndex, tutor.getEmail());
			ps.setString(++parameterIndex, tutor.getPassword());
			ResultSet rs = ps.executeQuery();
			if (rs != null) {
				if (rs.next()) {
					System.out.println("Tutor featched");
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean validateEmail(Tutor tutor) {
		String sql = "select * from tutor_register where email = ?";
		try {
			System.out.println(con);
			PreparedStatement ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setString(++parameterIndex, tutor.getEmail());
			ResultSet rs = ps.executeQuery();
			if (rs != null) {
				if (rs.next()) {
					System.out.println("Tutor Email featched");
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean updatePassword(Tutor tutor) {
		String sql = "update tutor_register set password=? Where email=?";
		boolean result = false;
		try {
			System.out.println(con);
			PreparedStatement ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setString(++parameterIndex, tutor.getPassword());
			ps.setString(++parameterIndex, tutor.getEmail());
			int i = ps.executeUpdate();
			if (i != 0) {
				result = true;
			} else {
				result = false;
			}
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return result;
	}

	public List<Tutor> fetchAllTutorStatus() {
		String sql = "select tutor_id, tutor_name, email, DOB, gender, mobile_no, address, password, qualification, courses from tutor_register where status='no'";
		List<Tutor> tutors = new ArrayList<Tutor>();
		PreparedStatement ps = null;
		try {
			System.out.println(sql);
			ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					Tutor tutor = new Tutor();
					int tutor_id = rs.getInt("tutor_id");
					String name = rs.getString("tutor_name");
					String email = rs.getString("email");
					Date date = rs.getDate("DOB");
					String gender = rs.getString("gender");
					String mobile_no = rs.getString("mobile_no");
					String address = rs.getString("address");
					String password = rs.getString("password");
					String qualification = rs.getString("qualification");
					String courses = rs.getString("courses");

					tutor.setTutor_id(tutor_id);
					tutor.setName(name);
					tutor.setEmail(email);
					tutor.setDOB(date);
					tutor.setGender(gender);
					tutor.setMobile_no(mobile_no);
					tutor.setAddress(address);
					tutor.setPassword(password);
					tutor.setQualification(qualification);
					tutor.setCourse(courses);

					tutors.add(tutor);
				}
				System.out.println("All fetched");
			} else {
				System.out.println("No Record Found");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return tutors;
	}

	public String updateTutorStatus(Tutor tutor) {
		String sql = "update tutor_register set tutor_name =?, email =?, DOB =?, gender =?, mobile_no =?, address =?, qualification =?, courses =?, status='yes' Where tutor_id=?";
		String result = "";
		PreparedStatement ps = null;
		try {
			System.out.println(sql);
			System.out.println(tutor);
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;

			ps.setString(++parameterIndex, tutor.getName());
			ps.setString(++parameterIndex, tutor.getEmail());
			ps.setDate(++parameterIndex, tutor.getDOB());
			ps.setString(++parameterIndex, tutor.getGender());
			ps.setString(++parameterIndex, tutor.getMobile_no());
			ps.setString(++parameterIndex, tutor.getAddress());
			ps.setString(++parameterIndex, tutor.getQualification());
			ps.setString(++parameterIndex, tutor.getCourse());
			ps.setInt(++parameterIndex, tutor.getTutor_id());

			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been updated";
			} else {
				result = "Failed to updated the data";
			}
		} catch (SQLException e) {
			result = "Failed to updated due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(result);
		System.out.println("---------------------------------------------------");
		return result;
	}

	public String deleteTutorStatus(Tutor tutor) {
		String sql = "DELETE FROM tutor_register WHERE tutor_id = ? and status='no'";
		String result = "";
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setInt(++parameterIndex, tutor.getTutor_id());
			// ps.setString(++parameterIndex, tutor.getEmail());
			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been deleted";
			} else {
				result = "failed to delete the data";
			}
		} catch (SQLException e) {
			result = "Failed to delete due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public String updateApplyCourse(Tutor tutor) {
		String sql = "update tutor_register set  qualification =?, courses =? Where tutor_id=?";
		String result = "";
		PreparedStatement ps = null;
		try {
			System.out.println(sql);
			System.out.println(tutor);
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setString(++parameterIndex, tutor.getQualification());
			ps.setString(++parameterIndex, tutor.getCourse());
			ps.setInt(++parameterIndex, tutor.getTutor_id());

			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been updated";
			} else {
				result = "Failed to updated the data";
			}
		} catch (SQLException e) {
			result = "Failed to updated due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(result);
		System.out.println("---------------------------------------------------");
		return result;
	}
	
}
