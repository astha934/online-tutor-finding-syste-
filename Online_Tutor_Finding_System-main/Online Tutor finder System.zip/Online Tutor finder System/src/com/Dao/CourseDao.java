package com.Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Dao.GenericDao;
import com.model.Course;

public class CourseDao extends GenericDao {

	public CourseDao() {
		getConnection();
	}

	public String insertCourse(Course course) {
		String sql = "insert into course(course_id, course_name) values(?, ?);";
		String result = "";
		PreparedStatement ps = null;
		try {
			System.out.println(con);
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setInt(++parameterIndex, course.getCourse_Id());
			ps.setString(++parameterIndex, course.getCourse_Name());

			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been inserted";
			} else {
				result = "Failed to insert the data";
			}
		} catch (SQLException e) {
			result = "Failed to insert due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(result);
		System.out.println("---------------------------------------------------");
		return result;
	}

	public String deleteCourse(Course course) {
		String sql = "DELETE FROM course WHERE course_id = ?";
		String result = "";
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setInt(++parameterIndex, course.getCourse_Id());
			// ps.setString(++parameterIndex, course.getEmail());
			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been deleted";
			} else {
				result = "failed to delete the data";
			}
		} catch (SQLException e) {
			result = "Failed to delete due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	public List<Course> fetchAllCourse() {
		String sql = "select course_id, course_name from course";
		List<Course> courses = new ArrayList<Course>();
		PreparedStatement ps = null;
		try {
			System.out.println(sql);
			ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					Course course = new Course();
					int course_id = rs.getInt("course_id");
					String course_name = rs.getString("course_name");

					course.setCourse_Id(course_id);
					course.setCourse_Name(course_name);

					courses.add(course);
				}
				System.out.println("All fetched");
			} else {
				System.out.println("No Record Found");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return courses;
	}
}
