package com.Dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Dao.GenericDao;
import com.model.Student;

public class StudentDao extends GenericDao {

	public StudentDao() {
		getConnection();
	}

	public String insertStudent(Student student) {
		String sql = "insert into student_register(student_id, student_name, email, DOB, gender, mobile_no, address, password, status) values(?, ?, ?, ?, ?, ?, ?, ?,'no')";
		String result = "";
		PreparedStatement ps = null;
		try {
			System.out.println(con);
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setInt(++parameterIndex, student.getStudent_id());
			ps.setString(++parameterIndex, student.getName());
			ps.setString(++parameterIndex, student.getEmail());
			ps.setDate(++parameterIndex, student.getDOB());
			ps.setString(++parameterIndex, student.getGender());
			ps.setString(++parameterIndex, student.getMobile_no());
			ps.setString(++parameterIndex, student.getAddress());
			ps.setString(++parameterIndex, student.getPassword());

			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been inserted";
			} else {
				result = "Failed to insert the data";
			}
		} catch (SQLException e) {
			result = "Failed to insert due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(result);
		System.out.println("---------------------------------------------------");
		return result;
	}

	public String updateStudent(Student student) {
		String sql = "update student_register set student_name =?, email =?, DOB =?, gender =?, mobile_no =?,  address =?,  school_name =?, class =?, subject_name =? Where student_id=?";
		String result = "";
		PreparedStatement ps = null;
		try {
			System.out.println(sql);
			System.out.println(student);
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;

			ps.setString(++parameterIndex, student.getName());
			ps.setString(++parameterIndex, student.getEmail());
			ps.setDate(++parameterIndex, student.getDOB());
			ps.setString(++parameterIndex, student.getGender());
			ps.setString(++parameterIndex, student.getMobile_no());
			ps.setString(++parameterIndex, student.getAddress());
			ps.setString(++parameterIndex, student.getShcool_name());
			ps.setString(++parameterIndex, student.getStudent_Class());
			ps.setString(++parameterIndex, student.getSubject());
			ps.setInt(++parameterIndex, student.getStudent_id());

			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been updated";
			} else {
				result = "Failed to updated the data";
			}
		} catch (SQLException e) {
			result = "Failed to updated due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(result);
		System.out.println("---------------------------------------------------");
		return result;
	}

	public String deleteStudent(Student student) {
		String sql = "DELETE FROM student_register WHERE student_id = ?";
		String result = "";
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setInt(++parameterIndex, student.getStudent_id());
			// ps.setString(++parameterIndex, student.getEmail());
			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been deleted";
			} else {
				result = "failed to delete the data";
			}
		} catch (SQLException e) {
			result = "Failed to delete due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	public List<Student> fetchAllStudent() {
		String sql = "select student_id, student_name, email, DOB, gender, mobile_no, address, password, school_name, class, subject_name from student_register where status='yes' ";
		List<Student> students = new ArrayList<Student>();
		PreparedStatement ps = null;
		try {
			System.out.println(sql);
			ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					Student student = new Student();
					int student_id = rs.getInt("student_id");
					String name = rs.getString("student_name");
					String email = rs.getString("email");
					Date date = rs.getDate("DOB");
					String gender = rs.getString("gender");
					String mobile_no = rs.getString("mobile_no");
					String address = rs.getString("address");
					String password = rs.getString("password");
					String school_name = rs.getString("school_name");
					String Class = rs.getString("class");
					String subject_name = rs.getString("subject_name");

					student.setStudent_id(student_id);
					student.setName(name);
					student.setEmail(email);
					student.setDOB(date);
					student.setGender(gender);
					student.setMobile_no(mobile_no);
					student.setAddress(address);
					student.setPassword(password);
					student.setShcool_name(school_name);
					student.setStudent_Class(Class);
					student.setSubject(subject_name);

					students.add(student);
				}
				System.out.println("All fetched");
			} else {
				System.out.println("No Record Found");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return students;
	}

	public String insertSaleList(List<Student> studentList) {
		String result = "";
		for (Student student : studentList) {
			result = insertStudent(student);
		}
		return result;
	}

	public boolean validateUser(Student student) {
		String sql = "select * from student_register where email = ? and password = ? and status='yes'";
		try {
			System.out.println(con);
			PreparedStatement ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setString(++parameterIndex, student.getEmail());
			ps.setString(++parameterIndex, student.getPassword());
			ResultSet rs = ps.executeQuery();
			if (rs != null) {
				if (rs.next()) {
					System.out.println("Student featched");
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean validateEmail(Student student) {
		String sql = "select * from student_register where email = ?";
		try {
			System.out.println(con);
			PreparedStatement ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setString(++parameterIndex, student.getEmail());
			ResultSet rs = ps.executeQuery();
			if (rs != null) {
				if (rs.next()) {
					System.out.println("Student Email featched");
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean updatePassword(Student student) {
		String sql = "update student_register set password=? Where email=?";
		boolean result = false;
		try {
			System.out.println(con);
			PreparedStatement ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setString(++parameterIndex, student.getPassword());
			ps.setString(++parameterIndex, student.getEmail());
			int i = ps.executeUpdate();
			if (i != 0) {
				result = true;
			} else {
				result = false;
			}
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return result;
	}

	public List<Student> fetchAllStudentStatus() {
		String sql = "select student_id, student_name, email, DOB, gender, mobile_no, address, password, school_name, class, subject_name from student_register where status='no' ";
		List<Student> students = new ArrayList<Student>();
		PreparedStatement ps = null;
		try {
			System.out.println(sql);
			ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					Student student = new Student();
					int student_id = rs.getInt("student_id");
					String name = rs.getString("student_name");
					String email = rs.getString("email");
					Date date = rs.getDate("DOB");
					String gender = rs.getString("gender");
					String mobile_no = rs.getString("mobile_no");
					String address = rs.getString("address");
					String password = rs.getString("password");
					String school_name = rs.getString("school_name");
					String Class = rs.getString("class");
					String subject_name = rs.getString("subject_name");

					student.setStudent_id(student_id);
					student.setName(name);
					student.setEmail(email);
					student.setDOB(date);
					student.setGender(gender);
					student.setMobile_no(mobile_no);
					student.setAddress(address);
					student.setPassword(password);
					student.setShcool_name(school_name);
					student.setStudent_Class(Class);
					student.setSubject(subject_name);

					students.add(student);
				}
				System.out.println("All fetched");
			} else {
				System.out.println("No Record Found");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return students;
	}

	public String updateStudentStatus(Student student) {
		String sql = "update student_register set student_name =?, email =?, DOB =?, gender =?, mobile_no =?,  address =?,  school_name =?, class =?, subject_name =?, status='yes' Where student_id=?";
		String result = "";
		PreparedStatement ps = null;
		try {
			System.out.println(sql);
			System.out.println(student);
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;

			ps.setString(++parameterIndex, student.getName());
			ps.setString(++parameterIndex, student.getEmail());
			ps.setDate(++parameterIndex, student.getDOB());
			ps.setString(++parameterIndex, student.getGender());
			ps.setString(++parameterIndex, student.getMobile_no());
			ps.setString(++parameterIndex, student.getAddress());
			ps.setString(++parameterIndex, student.getShcool_name());
			ps.setString(++parameterIndex, student.getStudent_Class());
			ps.setString(++parameterIndex, student.getSubject());
			ps.setInt(++parameterIndex, student.getStudent_id());

			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been updated";
			} else {
				result = "Failed to updated the data";
			}
		} catch (SQLException e) {
			result = "Failed to updated due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(result);
		System.out.println("---------------------------------------------------");
		return result;
	}


	
	public String deleteStudentStatus(Student student) {
		String sql = "DELETE FROM student_register WHERE student_id = ? and status='no' ";
		String result = "";
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setInt(++parameterIndex, student.getStudent_id());
			// ps.setString(++parameterIndex, student.getEmail());
			int i = ps.executeUpdate();
			if (i != 0) {
				result = "Record has been deleted";
			} else {
				result = "failed to delete the data";
			}
		} catch (SQLException e) {
			result = "Failed to delete due to error";
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}


public String updateApplyCourse(Student student) {
	String sql = "update student_register set   school_name =?, class =?, subject_name =? Where student_id=?";
	String result = "";
	PreparedStatement ps = null;
	try {
		System.out.println(sql);
		System.out.println(student);
		ps = con.prepareStatement(sql);
		int parameterIndex = 0;
		ps.setString(++parameterIndex, student.getShcool_name());
		ps.setString(++parameterIndex, student.getStudent_Class());
		ps.setString(++parameterIndex, student.getSubject());
		ps.setInt(++parameterIndex, student.getStudent_id());

		int i = ps.executeUpdate();
		if (i != 0) {
			result = "Record has been updated";
		} else {
			result = "Failed to updated the data";
		}
	} catch (SQLException e) {
		result = "Failed to updated due to error";
		e.printStackTrace();
	} finally {
		if (ps != null) {
			try {
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	System.out.println(result);
	System.out.println("---------------------------------------------------");
	return result;
}
}