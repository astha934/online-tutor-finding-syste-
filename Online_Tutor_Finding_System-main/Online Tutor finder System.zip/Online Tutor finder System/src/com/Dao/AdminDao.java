package com.Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Dao.GenericDao;
import com.model.Admin;

public class AdminDao extends GenericDao {

	public AdminDao() {
		getConnection();
	}

	public boolean validateUser(Admin admin) {
		String sql = "select * from admin_login where admin_Id = ? and password = ?";
		try {
			System.out.println(con);
			PreparedStatement ps = con.prepareStatement(sql);
			int parameterIndex = 0;
			ps.setString(++parameterIndex, admin.getAdmin_Id());
			ps.setString(++parameterIndex, admin.getPassword());
			ResultSet rs = ps.executeQuery();
			if (rs != null) {
				if (rs.next()) {
					System.out.println("Admin featched");
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

}
