package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.Student;
import com.util.MailUtils;

@WebServlet("/Email")
public class EmailController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String userId = req.getParameter("userId");
           
		HttpSession session1 = req.getSession();
		session1.setAttribute("email", userId);
		
		MailUtils mailUtils = new MailUtils();
		String code = mailUtils.getRandom();
	
		Student student = new Student(userId, code);

		boolean test = mailUtils.sendMail(student);
		System.out.println(test);
		if (test) {
			HttpSession session = req.getSession();
			session.setAttribute("students", student);
			resp.sendRedirect("verify.jsp");
		}
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
