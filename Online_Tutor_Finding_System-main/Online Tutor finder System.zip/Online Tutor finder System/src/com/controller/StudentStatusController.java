package com.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.StudentDao;
import com.model.Student;

@WebServlet("/StudentStatus")
public class StudentStatusController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String actionName = req.getParameter("actionName3");
		String result = "";
		String pageName = "studentStatus.jsp";
		StudentDao dao = new StudentDao();

		Student student = new Student();
		if (actionName != null) {
			String student_idStr = req.getParameter("student_id");
			String name = req.getParameter("Name");
			String email = req.getParameter("EmailID");
			String DOBstr = req.getParameter("DOB");
			String gender = req.getParameter("Gender");
			String mobile_no = req.getParameter("MobileNumber");
			String address = req.getParameter("Address");
			String password = req.getParameter("password");
			String school = req.getParameter("School");
			String student_Class = req.getParameter("Class");
			String subject_name = req.getParameter("Subject");
			

			if (student_idStr == null || student_idStr.equals("")) {
				student_idStr = "0";
			}
			int student_id = Integer.parseInt(student_idStr);
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			Date DateUtil = new Date(1234);
			try {
				DateUtil = sdf.parse(DOBstr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			java.sql.Date date = new java.sql.Date(DateUtil.getTime());

			student.setStudent_id(student_id);
			student.setName(name);
			student.setEmail(email);
			student.setDOB(date);
			student.setMobile_no(mobile_no);
			student.setGender(gender);
			student.setShcool_name(school);
			student.setAddress(address);
			student.setStudent_Class(student_Class);
			student.setPassword(password);
			student.setSubject(subject_name);

			if (actionName.equals("Approve")) {
				result = dao.updateStudentStatus(student);
			} else if (actionName.equals("Reject")) {
				result = dao.deleteStudentStatus(student);
			}
			resp.getWriter().print(result);
		} else {
			List<Student> students = dao.fetchAllStudentStatus();
			req.setAttribute("resultKey", result);
			req.setAttribute("students", students);
			RequestDispatcher rd = req.getRequestDispatcher(pageName);
			rd.forward(req, resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
