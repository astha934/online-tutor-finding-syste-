package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.StudentDao;
import com.model.Student;

@WebServlet("/Password")
public class PasswordCotroller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String password = req.getParameter("password");
		String varpassword = req.getParameter("varpassword");

		HttpSession session = req.getSession();
		String email = (String) session.getAttribute("email");

		String result = null;
		String pageName = "setPass.jsp";

		if (password.equals(varpassword)) {
			Student student = new Student();
			student.setEmail(email);
			student.setPassword(varpassword);
			boolean isUserValid = new StudentDao().updatePassword(student);
			if (isUserValid) {
				pageName = "studentlogin.jsp";
				result = "password sucsessfully reset...";
			} else {
				pageName = "setPass.jsp";
				result = "password do not match";
			}
		} else {
			result = "password do not match";
			pageName = "setPass.jsp";
		}
		req.setAttribute("resultKey", result);
		RequestDispatcher rd = req.getRequestDispatcher(pageName);
		rd.forward(req, resp);

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
