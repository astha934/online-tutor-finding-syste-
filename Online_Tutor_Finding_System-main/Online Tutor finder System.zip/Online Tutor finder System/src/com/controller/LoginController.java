package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.AdminDao;
import com.Dao.StudentDao;
import com.Dao.TutorDao;
import com.model.Admin;
import com.model.Student;
import com.model.Tutor;

@WebServlet("/Login")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String userId = req.getParameter("userId");
		String password = req.getParameter("password");
		String user_type = req.getParameter("user_type");

		String result = null;
		String pageName = "";
		
		Admin admin = new Admin();
		admin.setAdmin_Id(userId);
		admin.setPassword(password);

		Student student = new Student();
		student.setEmail(userId);
		student.setPassword(password);

		Tutor tutor = new Tutor();
		tutor.setEmail(userId);
		tutor.setPassword(password);

		if (user_type.equals("Admin")) {
			boolean isUserValid = new AdminDao().validateUser(admin);
			if (isUserValid) {
				HttpSession session1 = req.getSession();
				session1.setAttribute("userId", userId);
				
				pageName = "adminHome.jsp";
				req.setAttribute("adminKey", admin);
			} else {
				pageName = "login.jsp";
				result = "Invalid Username & Password...";
			}

		} else if (user_type.equals("Student")) {
			boolean isUserValid = new StudentDao().validateUser(student);
			if (isUserValid) {
				HttpSession session1 = req.getSession();
				session1.setAttribute("userId", userId);

				pageName = "studentHome.jsp";
				req.setAttribute("studentKey", student);
			} else {
				pageName = "login.jsp";
				result = "Invalid Username & Password...";
			}

		} else if (user_type.equals("Tutor")) {
			boolean isUserValid = new TutorDao().validateUser(tutor);
			if (isUserValid) {
				HttpSession session1 = req.getSession();
				session1.setAttribute("userId", userId);

				pageName = "tutorHome.jsp";
				req.setAttribute("tutorKey", userId);
			} else {
				pageName = "login.jsp";
				result = "Invalid Username & Password...";
			}
		}

		req.setAttribute("loginKey", result);
		RequestDispatcher rd = req.getRequestDispatcher(pageName);
		rd.forward(req, resp);

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
