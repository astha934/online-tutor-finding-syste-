package com.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.TutorDao;
import com.model.Tutor;

@WebServlet("/Status")
public class TutorStatusController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String actionName = req.getParameter("actionName1");
		String result = "";
		String pageName = "tutorStatus.jsp";
		TutorDao dao = new TutorDao();

		Tutor tutor = new Tutor();
		if (actionName != null) {
			String tutor_idStr = req.getParameter("tutor_id");
			String name = req.getParameter("Name");
			String email = req.getParameter("EmailID");
			String DOBstr = req.getParameter("DOB");
			String gender = req.getParameter("Gender");
			String mobile_no = req.getParameter("MobileNumber");
			String address = req.getParameter("Address");
			String password = req.getParameter("password");
			String qualification = req.getParameter("Qualification");
			String courses = req.getParameter("Courses");
			

			if (tutor_idStr == null || tutor_idStr.equals("")) {
				tutor_idStr = "0";
			}
			int tutor_id = Integer.parseInt(tutor_idStr);
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			Date DateUtil = new Date(1234);
			try {
				DateUtil = sdf.parse(DOBstr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			java.sql.Date date = new java.sql.Date(DateUtil.getTime());

			
			tutor.setTutor_id(tutor_id);
			tutor.setName(name);
			tutor.setEmail(email);
			tutor.setDOB(date);
			tutor.setMobile_no(mobile_no);
			tutor.setGender(gender);
			tutor.setQualification(qualification);
			tutor.setCourse(courses);
			tutor.setAddress(address);
			tutor.setPassword(password);

			if (actionName.equals("Approve")) {
				result = dao.updateTutorStatus(tutor);
			} else if (actionName.equals("Reject")) {
				result = dao.deleteTutorStatus(tutor);
			}
			resp.getWriter().print(result);
		    } else {
			List<Tutor> tutors = dao.fetchAllTutorStatus();
			req.setAttribute("resultKey", result);
			req.setAttribute("tutors", tutors);
			RequestDispatcher rd = req.getRequestDispatcher(pageName);
			rd.forward(req, resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
