package com.controller;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.CourseDao;
import com.Dao.TutorDao;
import com.model.Course;
import com.model.Tutor;

@WebServlet("/TutorApply")
public class TutorApplyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String actionName = req.getParameter("actionNameCourse");
		String result = "";
		String pageName = "tutorApplyCourse.jsp";
		TutorDao dao = new TutorDao();

		Tutor tutor = new Tutor();

		if (actionName != null) {
			String tutor_idStr = req.getParameter("tutor_id");
			String name = req.getParameter("Name");
			String email = req.getParameter("EmailID");
			String DOBstr = req.getParameter("DOB");
			String mobile_no = req.getParameter("MobileNumber");
			String gender = req.getParameter("Gender");
			String qualification = req.getParameter("Qualification");
			String courses = req.getParameter("Courses");
			String address = req.getParameter("Address");
			String password = req.getParameter("password");

			if (tutor_idStr == null || tutor_idStr.equals("")) {
				tutor_idStr = "0";
			}
			int tutor_id = Integer.parseInt(tutor_idStr);

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			Date DateUtil = new Date(1234);
			try {
				DateUtil = sdf.parse(DOBstr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			java.sql.Date date = new java.sql.Date(DateUtil.getTime());

			tutor.setTutor_id(tutor_id);
			tutor.setName(name);
			tutor.setEmail(email);
			tutor.setDOB(date);
			tutor.setMobile_no(mobile_no);
			tutor.setGender(gender);
			tutor.setQualification(qualification);
			tutor.setCourse(courses);
			tutor.setAddress(address);
			tutor.setPassword(password);

			if (actionName.equals("Apply")) {
				result = dao.updateApplyCourse(tutor);
			}

			resp.getWriter().print(result);

		} else {
			CourseDao CourseDao = new CourseDao();
			List<Course> courseslist = CourseDao.fetchAllCourse();
			req.setAttribute("courses", courseslist);

			java.sql.Connection con = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tutorsystem", "root", "sahu");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			HttpSession session = req.getSession();
			String userId = (String) session.getAttribute("userId");

			String sql = "select tutor_id, tutor_name, email, DOB, gender, mobile_no, address, password, qualification, courses from tutor_register where status='yes' and email ='"
					+ userId + "'";
			List<Tutor> tutors = new ArrayList<Tutor>();
			PreparedStatement ps = null;
			try {
				System.out.println(sql);
				ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();

				if (rs != null) {
					while (rs.next()) {
						Tutor tutor1 = new Tutor();
						int tutor_id = rs.getInt("tutor_id");
						String name = rs.getString("tutor_name");
						String email = rs.getString("email");
						java.sql.Date date = rs.getDate("DOB");
						String gender = rs.getString("gender");
						String mobile_no = rs.getString("mobile_no");
						String address = rs.getString("address");
						String password = rs.getString("password");
						String qualification = rs.getString("qualification");
						String courses = rs.getString("courses");

						tutor1.setTutor_id(tutor_id);
						tutor1.setName(name);
						tutor1.setEmail(email);
						tutor1.setDOB(date);
						tutor1.setGender(gender);
						tutor1.setMobile_no(mobile_no);
						tutor1.setAddress(address);
						tutor1.setPassword(password);
						tutor1.setQualification(qualification);
						tutor1.setCourse(courses);

						tutors.add(tutor1);
					}
					System.out.println("All fetched1");
				} else {
					System.out.println("No Record Found");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (ps != null) {
					try {
						ps.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}

			req.setAttribute("tutors", tutors);
			RequestDispatcher rd = req.getRequestDispatcher(pageName);
			rd.forward(req, resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
