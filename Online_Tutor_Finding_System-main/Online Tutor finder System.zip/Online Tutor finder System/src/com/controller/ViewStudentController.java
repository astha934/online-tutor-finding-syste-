package com.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.StudentDao;
import com.model.Student;

@WebServlet("/ViewStudent")
public class ViewStudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String student_idStr = req.getParameter("student_id");
		String name = req.getParameter("Name");
		String email = req.getParameter("EmailID");
		String DOBstr = req.getParameter("DOB");
		String mobile_no = req.getParameter("MobileNumber");
		String gender = req.getParameter("Gender");
		String school = req.getParameter("School");
		String student_Class = req.getParameter("Class");
		String subject_name = req.getParameter("Subject");
		String address = req.getParameter("Address");
		String password = req.getParameter("password");

		if (student_idStr == null || student_idStr.equals("")) {
			student_idStr = "0";
		}
		int student_id = Integer.parseInt(student_idStr);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		Date DateUtil = new Date(1234);
		try {
			DateUtil = sdf.parse(DOBstr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		java.sql.Date date = new java.sql.Date(DateUtil.getTime());

		Student student = new Student();
		student.setStudent_id(student_id);
		student.setName(name);
		student.setEmail(email);
		student.setDOB(date);
		student.setMobile_no(mobile_no);
		student.setGender(gender);
		student.setShcool_name(school);
		student.setStudent_Class(student_Class);
		student.setSubject(subject_name);
		student.setAddress(address);
		student.setPassword(password);

		StudentDao dao = new StudentDao();
		String result = dao.updateStudent(student);
        
		System.out.println(result);
		req.setAttribute("result", result);
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
