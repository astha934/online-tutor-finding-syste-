package com.controller;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.CourseDao;
import com.model.Course;

@WebServlet("/Course")
public class CourseController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String actionName = req.getParameter("actionCourseName");
		String result = "";
		String pageName = "addCourse.jsp";
		CourseDao dao = new CourseDao();

		Course course = new Course();
		if (actionName != null) {
			String course_idStr = req.getParameter("course_id");
			String name = req.getParameter("course_name");

			if (course_idStr == null || course_idStr.equals("")) {
				course_idStr = "0";
			}
			int course_id = Integer.parseInt(course_idStr);

			course.setCourse_Id(course_id);
			course.setCourse_Name(name);

			if (actionName.equals("Add")) {
				result = dao.insertCourse(course);
			} else if (actionName.equals("Delete")) {
				result = dao.deleteCourse(course);
			}
			resp.getWriter().print(result);
		} else {
			List<Course> courses = dao.fetchAllCourse();
			req.setAttribute("resultKey", result);
			req.setAttribute("courses", courses);
			RequestDispatcher rd = req.getRequestDispatcher(pageName);
			rd.forward(req, resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
