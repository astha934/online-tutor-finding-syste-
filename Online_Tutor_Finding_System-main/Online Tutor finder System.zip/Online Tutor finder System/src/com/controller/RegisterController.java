package com.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.StudentDao;
import com.Dao.TutorDao;
import com.model.Student;
import com.model.Tutor;

@WebServlet("/Register")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String result = "";

		String user_idStr = req.getParameter("user_Id");
		String user_name = req.getParameter("user_Name");
		String email = req.getParameter("email_ID");
		String DOBstr = req.getParameter("DOB");
		String gender = req.getParameter("gender");
		String mobile_no = req.getParameter("mobile_Number");
		String address = req.getParameter("address");
		String password = req.getParameter("password");
		String user_type = req.getParameter("user_type");

		if (user_idStr == null || user_idStr.equals("")) {
			user_idStr = "0";
		}
		int user_id = Integer.parseInt(user_idStr);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		Date DateUtil = new Date(1234);
		try {
			DateUtil = sdf.parse(DOBstr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		java.sql.Date date = new java.sql.Date(DateUtil.getTime());

		if (user_type.equals("Student")) {
			Student student = new Student();

			student.setStudent_id(user_id);
			student.setName(user_name);
			student.setEmail(email);
			student.setDOB(date);
			student.setGender(gender);
			student.setMobile_no(mobile_no);
			student.setAddress(address);
			student.setPassword(password);

			StudentDao dao = new StudentDao();
			result = dao.insertStudent(student);

		} else if (user_type.equals("Tutor")) {
			Tutor tutor = new Tutor();

			tutor.setTutor_id(user_id);
			tutor.setName(user_name);
			tutor.setEmail(email);
			tutor.setDOB(date);
			tutor.setGender(gender);
			tutor.setMobile_no(mobile_no);
			tutor.setGender(gender);
			tutor.setAddress(address);
			tutor.setPassword(password);

			TutorDao dao = new TutorDao();
			result = dao.insertTutor(tutor);

		}
		req.setAttribute("resultKey", result);
		RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
		rd.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}