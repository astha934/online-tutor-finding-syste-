package com.controller;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.CourseDao;
import com.Dao.StudentDao;
import com.model.Course;
import com.model.Student;

@WebServlet("/StudentApply")
public class StudentApplyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String actionName = req.getParameter("actionCourseName1");
		String result = "";
		String pageName = "studentApplyCourse.jsp";
		StudentDao dao = new StudentDao();

		Student student = new Student();

		if (actionName != null) {
			String student_idStr = req.getParameter("student_id");
			String name = req.getParameter("Name");
			String email = req.getParameter("EmailID");
			String DOBstr = req.getParameter("DOB");
			String mobile_no = req.getParameter("MobileNumber");
			String gender = req.getParameter("Gender");
			String address = req.getParameter("Address");
			String password = req.getParameter("password");
			String school = req.getParameter("School");
			String student_Class = req.getParameter("Class");
			String subject_name = req.getParameter("Subject");

			if (student_idStr == null || student_idStr.equals("")) {
				student_idStr = "0";
			}
			int student_id = Integer.parseInt(student_idStr);

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			Date DateUtil = new Date(1234);
			try {
				DateUtil = sdf.parse(DOBstr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			java.sql.Date date = new java.sql.Date(DateUtil.getTime());

			student.setStudent_id(student_id);
			student.setName(name);
			student.setEmail(email);
			student.setDOB(date);
			student.setMobile_no(mobile_no);
			student.setGender(gender);
			student.setAddress(address);
			student.setPassword(password);
			student.setStudent_Class(student_Class);
			student.setShcool_name(school);
			student.setSubject(subject_name);

			if (actionName.equals("Apply")) {
				result = dao.updateApplyCourse(student);
			}

			resp.getWriter().print(result);

		} else {
			CourseDao CourseDao = new CourseDao();
			List<Course> courseslist = CourseDao.fetchAllCourse();
			req.setAttribute("courses", courseslist);

			java.sql.Connection con = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tutorsystem", "root", "sahu");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			HttpSession session = req.getSession();
			String userId = (String) session.getAttribute("userId");

			String sql = "select student_id, student_name, email, DOB, gender, mobile_no, address, password, school_name, class, subject_name from student_register where status='yes' and email ='"
					+ userId + "'";
			List<Student> students = new ArrayList<Student>();
			PreparedStatement ps = null;
			try {
				System.out.println(sql);
				ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();

				if (rs != null) {
					while (rs.next()) {
						Student student1 = new Student();
						int student_id = rs.getInt("student_id");
						String name = rs.getString("student_name");
						String email = rs.getString("email");
						java.sql.Date date = rs.getDate("DOB");
						String gender = rs.getString("gender");
						String mobile_no = rs.getString("mobile_no");
						String address = rs.getString("address");
						String password = rs.getString("password");
						String school = req.getParameter("School");
						String student_Class = req.getParameter("Class");
						String subject_name = req.getParameter("Subject");


						student1.setStudent_id(student_id);
						student1.setName(name);
						student1.setEmail(email);
						student1.setDOB(date);
						student1.setGender(gender);
						student1.setMobile_no(mobile_no);
						student1.setAddress(address);
						student1.setPassword(password);
						student1.setStudent_Class(student_Class);
						student1.setShcool_name(school);
						student1.setSubject(subject_name);
						

						students.add(student1);
					}
					System.out.println("All fetched1");
				} else {
					System.out.println("No Record Found");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (ps != null) {
					try {
						ps.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
			req.setAttribute("students", students);
			System.out.println(students);
			RequestDispatcher rd = req.getRequestDispatcher(pageName);
			rd.forward(req, resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
