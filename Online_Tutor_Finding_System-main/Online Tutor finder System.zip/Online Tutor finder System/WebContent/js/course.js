function deleteCourse(id, Name) {
	document.getElementById('headerIdCourse').innerHTML = "Delete Course";
	$('#course_id').val(id);
	$('#course_name').val(Name);

	$('#course_id').attr('readOnly', true);
	$('#course_name').attr('readOnly', true);

	document.getElementById('actionIdCourse').value = 'Delete';
	document.getElementById('deleteBtnIdCourse').style.display = "block";
	document.getElementById('addBtnIdCourse').style.display = "none";
}

function viewCourse(id, Name) {
	document.getElementById('headerIdCourse').innerHTML = "View Course";
	$('#course_id').val(id);
	$('#course_name').val(Name);

	$('#course_id').attr('readOnly', true);
	$('#course_name').attr('readOnly', true);

	document.getElementById('addBtnIdCourse').style.display = "none";
	document.getElementById('deleteBtnIdCourse').style.display = "none";
}

function add() {
	document.getElementById('headerIdCourse').innerHTML = "Add Course";
	document.getElementById('addBtnIdCourse').style.display = "block";
	document.getElementById('deleteBtnIdCourse').style.display = "none";

	$('#course_id').attr('readOnly', false);
	$('#course_name').attr('readOnly', false);
}

function loadCourse() {
	$('#mainContentId').load('Course', function() {
		$('#myTable').bootstrapTable()
		$('#myTable').bootstrapTable('refreshOptions', {
			locale : 'en-US',
			sortable : true
		})
	});
}

function actionFormCourse() {
	var dataString = $('#courseFormId').serialize();
	console.log(dataString);
	$.ajax({
		type : "POST",
		url : "Course",
		data : dataString,
		success : function(data) {
			$('#messageIdCourse').html(data);
			console.log(data);
		}
	});
}
