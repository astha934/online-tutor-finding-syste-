
function deleteTutor(id, name, email, dob, mobile_no, gender, qualification, course, address) {
	document.getElementById('headerId').innerHTML = "Delete Tutor";
	$('#tutor_id').val(id);
	$('#Name').val(name);
	$('#EmailID').val(email);
	$('#DOB').val(dob);
	$('#MobileNumber').val(mobile_no);
	$('#Gender').val(gender);
	$('#Qualification').val(qualification);
	$('#Courses').val(course);
	$('#Address').val(address);
	
	$('#tutor_id').attr('readOnly', true);
	$('#Name').attr('readOnly', true);
	$('#EmailID').attr('readOnly', true);
	$('#DOB').attr('readOnly', true);
	$('#MobileNumber').attr('readOnly', true);
	$('#Gender').attr('readOnly', true);
	$('#Qualification').attr('readOnly', true);
	$('#Courses').attr('readOnly', true);
	$('#Address').attr('readOnly', true);
	
	document.getElementById('actionId').value = 'Delete';
	document.getElementById('deleteBtnId').style.display="block";
	document.getElementById('updateBtnId').style.display = "none";
}

function updateTutor(id, name, email, dob, mobile_no, gender, qualification, course, address) {
	document.getElementById('headerId').innerHTML = "Update Tutor";
	$('#tutor_id').val(id);
	
	$('#tutor_id').attr('readOnly', true);
	$('#Name').attr('readOnly', false);
	$('#EmailID').attr('readOnly', false);
	$('#DOB').attr('readOnly', false);
	$('#MobileNumber').attr('readOnly', false);
	$('#Gender').attr('readOnly', false);
	$('#Qualification').attr('readOnly', false);
	$('#Courses').attr('readOnly', false);
	$('#Address').attr('readOnly', false);
	
	$('#Name').val(name);
	$('#EmailID').val(email);
	$('#DOB').val(dob);
	$('#MobileNumber').val(mobile_no);
	$('#Gender').val(gender);
	$('#Qualification').val(qualification);
	$('#Courses').val(course);
	$('#Address').val(address);

	document.getElementById('actionId').value = 'Update';
	document.getElementById('updateBtnId').style.display="block";
	document.getElementById('deleteBtnId').style.display = "none";
}

function viewTutor(id, name, email, dob, mobile_no, gender, qualification, course, address) {
	document.getElementById('headerId').innerHTML = "View Tutor";
	$('#tutor_id').val(id);
	$('#Name').val(name);
	$('#EmailID').val(email);
	$('#DOB').val(dob);
	$('#MobileNumber').val(mobile_no);
	$('#Gender').val(gender);
	$('#Qualification').val(qualification);
	$('#Courses').val(course);
	$('#Address').val(address);

	$('#tutor_id').attr('readOnly', true);
	$('#Name').attr('readOnly', true);
	$('#EmailID').attr('readOnly', true);
	$('#DOB').attr('readOnly', true);
	$('#MobileNumber').attr('readOnly', true);
	$('#Gender').attr('readOnly', true);
	$('#Qualification').attr('readOnly', true);
	$('#Courses').attr('readOnly', true);
	$('#Address').attr('readOnly', true);
	
	document.getElementById('updateBtnId').style.display = "none";
	document.getElementById('deleteBtnId').style.display = "none";
}
 
function loadTutor(){
	  $('#mainContentId').load('Tutor', function(){
		  $('#myTable').bootstrapTable()
		  $('#myTable').bootstrapTable('refreshOptions', {
		        locale: 'en-US',
		        sortable: true
		      })
	  });
}

function actionForm2(){
	var dataString = $('#tutorFormId').serialize();
	console.log(dataString);
	$.ajax({
	      type: "POST",
	      url: "Tutor",
	      data: dataString,
	      success: function(data) {
	    	  $('#messageId2').html(data);
	    	  console.log(data);
	      }
	    });
}
