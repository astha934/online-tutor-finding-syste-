function viewProfileStudent() {
	$('#mainContentId').load('viewStudent.jsp', function() {
		$('#studentFormId').serialize();
	});
}

function actionViewStudentForm() {
	var dataString = $('#studentFormId').serialize();
	console.log(dataString);
	$.ajax({
		type : "POST",
		url : "ViewStudent",
		data : dataString,
		success : function(data) {
			$('#messageViewStudentId').html(data);
			console.log(data);
		}
	});
}