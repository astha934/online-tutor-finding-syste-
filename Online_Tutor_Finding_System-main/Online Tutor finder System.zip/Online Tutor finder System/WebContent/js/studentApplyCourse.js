
function updateCourseStudent(id, name, email, dob, mobile_no, gender, school, Class, subject, address) {
	$('#student_id').val(id);
	
	$('#student_id').attr('readOnly', true);
	$('#Name').attr('readOnly', false);
	$('#EmailID').attr('readOnly', false);
	$('#DOB').attr('readOnly', false);
	$('#MobileNumber').attr('readOnly', false);
	$('#Gender').attr('readOnly', false);
	$('#School').attr('readOnly', false);
	$('#Class').attr('readOnly', false);
	$('#Subject').attr('readOnly', false);
	$('#Address').attr('readOnly', false);
	
	$('#Name').val(name);
	$('#EmailID').val(email);
	$('#DOB').val(dob);
	$('#MobileNumber').val(mobile_no);
	$('#Gender').val(gender);
	$('#School').val(school);
	$('#Class').val(Class);
	$('#Subject').val(subject);
	$('#Address').val(address);

	document.getElementById('actionCourseId1').value = 'Apply';
	document.getElementById('updateCourseBtnId').style.display="block";
}
 
function loadStudentCourse(){
	  $('#mainContentId').load('StudentApply', function(){
		  $('#myTable').bootstrapTable()
		  $('#myTable').bootstrapTable('refreshOptions', {
		        locale: 'en-US',
		        sortable: true
		      })
	  });
}

function actionFormStudentCourse(){
	var dataString = $('#studentCourseFormId').serialize();
	console.log(dataString);
	$.ajax({
	      type: "POST",
	      url: "StudentApply",
	      data: dataString,
	      success: function(data) {
	    	  $('#messageCourseId1').html(data);
	    	  console.log(data);
	      }
	    });
}
