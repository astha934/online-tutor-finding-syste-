function viewProfile() {
	$('#mainContentId').load('viewTutorProfile.jsp', function() {
		$('#tutorFormId').serialize();
	});
}

function actionViewTuorForm() {
	var dataString = $('#tutorFormId').serialize();
	console.log(dataString);
	$.ajax({
		type : "POST",
		url : "ViewTutorProfile",
		data : dataString,
		success : function(data) {
			$('#messageViewTutorId').html(data);
			console.log(data);
		}
	});
}