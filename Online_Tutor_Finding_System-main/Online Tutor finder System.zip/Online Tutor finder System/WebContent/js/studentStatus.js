function deleteStudent(id, name, email, dob, mobile_no, gender, school, Class, subject, address) {
	document.getElementById('headerId').innerHTML = "Reject Student";
	$('#student_id').val(id);
	$('#Name').val(name);
	$('#EmailID').val(email);
	$('#DOB').val(dob);
	$('#MobileNumber').val(mobile_no);
	$('#Gender').val(gender);
	$('#School').val(school);
	$('#Class').val(Class);
	$('#Subject').val(subject);
	$('#Address').val(address);

	$('#student_id').attr('readOnly', true);
	$('#Name').attr('readOnly', true);
	$('#EmailID').attr('readOnly', true);
	$('#DOB').attr('readOnly', true);
	$('#MobileNumber').attr('readOnly', true);
	$('#Gender').attr('readOnly', true);
	$('#School').attr('readOnly', true);
	$('#Class').attr('readOnly', true);
	$('#Subject').attr('readOnly', true);
	$('#Address').attr('readOnly', true);

	document.getElementById('actionId').value = 'Reject';
	document.getElementById('deleteBtnId').style.display = "block";
	document.getElementById('updateBtnId').style.display = "none";
}

function updateStudent(id, name, email, dob, mobile_no, gender, school, Class, subject, address) {
	document.getElementById('headerId').innerHTML = "Approve Student";
	$('#student_id').val(id);

	$('#student_id').attr('readOnly', true);
	$('#Name').attr('readOnly', false);
	$('#EmailID').attr('readOnly', false);
	$('#DOB').attr('readOnly', false);
	$('#MobileNumber').attr('readOnly', false);
	$('#Gender').attr('readOnly', false);
	$('#School').attr('readOnly', false);
	$('#Class').attr('readOnly', false);
	$('#Subject').attr('readOnly', false);
	$('#Address').attr('readOnly', false);

	$('#Name').val(name);
	$('#EmailID').val(email);
	$('#DOB').val(dob);
	$('#MobileNumber').val(mobile_no);
	$('#Gender').val(gender);
	$('#School').val(school);
	$('#Class').val(Class);
	$('#Subject').val(subject);
	$('#Address').val(address);

	document.getElementById('actionId').value = 'Approve';
	document.getElementById('updateBtnId').style.display = "block";
	document.getElementById('deleteBtnId').style.display = "none";
}

function loadStudentStatus() {
	$('#mainContentId').load('StudentStatus', function() {
		$('#myTable').bootstrapTable()
		$('#myTable').bootstrapTable('refreshOptions', {
			locale : 'en-US',
			sortable : true
		})
	});
}

function actionForm3() {
	var dataString = $('#studentStatusFormId').serialize();
	console.log(dataString);
	$.ajax({
		type : "POST",
		url : "StudentStatus",
		data : dataString,
		success : function(data) {
			$('#messageId3').html(data);
			console.log(data);
		}
	});
}