
function updateCourseTutor(id, name, email, dob, mobile_no, gender, qualification, course, address) {
	document.getElementById('headerCourseId').innerHTML = "Apply Course";
	$('#tutor_id').val(id);
	
	$('#tutor_id').attr('readOnly', true);
	$('#Name').attr('readOnly', false);
	$('#EmailID').attr('readOnly', false);
	$('#DOB').attr('readOnly', false);
	$('#MobileNumber').attr('readOnly', false);
	$('#Gender').attr('readOnly', false);
	$('#Qualification').attr('readOnly', false);
	$('#Courses').attr('readOnly', false);
	$('#Address').attr('readOnly', false);
	
	$('#Name').val(name);
	$('#EmailID').val(email);
	$('#DOB').val(dob);
	$('#MobileNumber').val(mobile_no);
	$('#Gender').val(gender);
	$('#Qualification').val(qualification);
	$('#Courses').val(course);
	$('#Address').val(address);

	document.getElementById('actionCourseId').value = 'Apply';
	document.getElementById('updateCourseBtnId').style.display="block";
}
 
function loadCourseTutor(){
	  $('#mainContentId').load('TutorApply', function(){
		  $('#myTable').bootstrapTable()
		  $('#myTable').bootstrapTable('refreshOptions', {
		        locale: 'en-US',
		        sortable: true
		      })
	  });
}

function actionCourseForm(){
	var dataString = $('#tutorCourseFormId').serialize();
	console.log(dataString);
	$.ajax({
	      type: "POST",
	      url: "TutorApply",
	      data: dataString,
	      success: function(data) {
	    	  $('#messageCourseId').html(data);
	    	  console.log(data);
	      }
	    });
}
