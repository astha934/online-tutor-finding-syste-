function onLinkClick(obj){
	$('#sideBarId li').each(function(){
		$(this).find('a:first').removeClass('active');
	});
	
	$(obj).addClass('active');
}